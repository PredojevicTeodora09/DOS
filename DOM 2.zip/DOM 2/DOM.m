% Zadatak je da se nakon potiskivanja šuma slika segmentira
% u dve klase piksela proizvoljnim izborom praga sjajnosti. 
% Nakon potrebne morfološke obrade i utvrđivanja povezanih regiona, 
% odrediti regione likova slova i izračunati položaje njihovih centroida, 
% površine i obime.

%% Početne komande

close all;
clear all;
clc;

%% Učitaj sliku

slika=imread('slika 206_1.jpg');  
slika_1=im2double(slika);

%% Ispisivanje osnovnih informacija o slici
info_slike = imfinfo('slika 206_1.jpg');

disp('Osnovne informacije o slici:');
disp(['Ime datoteke: ', info_slike.Filename]);
disp(['Širina slike: ', num2str(info_slike.Width)]);
disp(['Visina slike: ', num2str(info_slike.Height)]);
disp(['Broj kanala boja: ', num2str(info_slike.NumberOfSamples)]);

%% Prikaz originalne slike

figure(1);
imshow(slika); title('Originalna slika');

%% Prikazivanje histograma originalne slike

figure(2);
h1 = imhist(slika_1); bar(h1); title('Histogram originalne slike');

%% Potiskivanje šuma - > Gausov filtar

%filtrirana_slika = imgaussfilt(slika, 0.6);
filtrirana_slika = medfilt2(slika,[7 7]);
filtrirana_slika_1 =im2double(filtrirana_slika);

%% Prikaz filtrirane slike

figure(3);
imshow(filtrirana_slika_1);title('Filtrirana slika');

%% Prikazivanje histograma filtrirane slike

figure(4);
h2 = imhist(filtrirana_slika_1); bar(h2); title('Histogram filtrirane slike');

%% 1. Postavljanje praga sjajnosti proizvoljnim izborom

prag_sjajnosti = 0.5; 

%% Binarna segmentacija slike

binarna_slika = imbinarize(filtrirana_slika, prag_sjajnosti);

%% Prikaz segmentacije proizvoljnim pragom

figure(5);
imshow(binarna_slika), title('Segmentacije proizvoljnim pragom');

%% Morfoloske operacije

se = strel('square', 3); 
binarna_slika_1 = imdilate(binarna_slika ,se);
figure(6); 
imshow(binarna_slika_1), title('Binarna_slika_1 - Dilatacija');

se = strel('square',3);                      
binarna_slika_2 = imopen(binarna_slika ,se);
figure(7); 
imshow(binarna_slika_2), title('Binarna_slika_2 - Otvaranje');

se = strel('square',3);                      
binarna_slika_3 = imclose(binarna_slika_2 ,se);
figure(8); 
imshow(binarna_slika_3), title('Binarna_slika_3 - Zatvaranje');

%% Utvrđivanje povezanih regiona

povezani_regioni = bwlabel(binarna_slika_1);

%% Izračunavanje svojstava povezanih regiona

podaci_regiona = regionprops(povezani_regioni, 'Centroid', 'Area', 'Perimeter');

% Ispisivanje informacija o regijama
for i = 1:numel(podaci_regiona)
    fprintf('Region %d: Centroid = (%.2f, %.2f), Površina = %.2f, Obim = %.2f\n', ...
        i, podaci_regiona(i).Centroid(1), podaci_regiona(i).Centroid(2), ...
        podaci_regiona(i).Area, podaci_regiona(i).Perimeter);
end

%% Prikazivanje povezanih regiona segmentacije 

figure(9);
imshow(label2rgb(povezani_regioni)), title('Regioni likova slova');







